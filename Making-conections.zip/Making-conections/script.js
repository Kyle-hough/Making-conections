function change(element){
    var name = document.querySelector (".card-body h1");
    name.innerText = "John Doe";
    console.log (name);
}

function removeTod(Tod){
    var Tod = document.querySelector (".Todd")
    Tod.remove();
}

function removePhil(Phil){
    var Phil = document.querySelector (".Phil")
    Phil.remove();
}